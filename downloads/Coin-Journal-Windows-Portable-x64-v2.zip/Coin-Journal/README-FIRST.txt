﻿Coin Journal - Windows 실행 안내 (v2)

1. ZIP 파일을 우클릭해 '모두 압축 풀기'를 선택합니다.
2. 압축을 푼 Coin-Journal 폴더에서 START.cmd를 더블클릭합니다.
3. OKX 설정창에 키를 입력하거나 '나중에'를 누릅니다.
4. 브라우저에서 매매일지와 포지션 계산기가 열립니다.
5. OKX 설정을 미뤘다면 나중에 SETUP-OKX.cmd를 실행합니다.

기존 폴더를 삭제할 필요는 없습니다. 새 폴더에 압축을 풀어 사용하세요.
API 키는 Windows 사용자 계정으로 암호화되며 ZIP 파일에 포함되지 않습니다.
키를 입력하지 않아도 매매일지와 계산기를 사용할 수 있습니다.

실패했을 때:
- DIAGNOSE.cmd를 더블클릭합니다.
- 오류 문구가 표시된 부분을 보내주시면 해당 오류를 기준으로 진단할 수 있습니다.
- API Key, Secret Key, Passphrase, credentials.json은 보내지 마세요.

패키지는 Windows x64용입니다. Node.js 실행 파일을 포함합니다.
실제 Windows PC에서의 화면 실행 검증은 사용자 환경에서 필요합니다.
