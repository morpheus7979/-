@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if not exist "%~dp0windows\Start-CoinJournal.ps1" goto missing
powershell.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0windows\Start-CoinJournal.ps1"
if errorlevel 1 (
  echo.
  echo Startup failed. Run DIAGNOSE.cmd or share the error text above.
  pause
)
exit /b
:missing
echo Please extract the entire ZIP using Extract All, then run START.cmd.
pause
exit /b 1
