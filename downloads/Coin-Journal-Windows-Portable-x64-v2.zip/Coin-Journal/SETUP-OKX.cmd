@echo off
setlocal
chcp 65001 >nul
powershell.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0windows\Start-CoinJournal.ps1" -Configure
if errorlevel 1 pause
