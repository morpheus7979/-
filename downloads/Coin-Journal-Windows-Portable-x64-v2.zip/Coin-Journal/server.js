import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import { createOkxClient, OkxError } from './lib/okx.js';

const files = { '/': 'index.html', '/app.js': 'app.js', '/style.css': 'style.css', '/finance.js': 'finance.js', '/okx-ui.js': 'okx-ui.js', '/manifest.webmanifest': 'manifest.webmanifest', '/service-worker.js': 'service-worker.js', '/icon.svg': 'icon.svg' };
const types = { html: 'text/html; charset=utf-8', js: 'text/javascript; charset=utf-8', css: 'text/css; charset=utf-8', webmanifest: 'application/manifest+json; charset=utf-8', svg: 'image/svg+xml' };
const securityHeaders = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'X-Frame-Options': 'DENY',
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
};

function json(res, status, value) {
  res.writeHead(status, { ...securityHeaders, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(value));
}

export function createApp({ okx = createOkxClient() } = {}) {
  return http.createServer(async (req, res) => {
    let path;
    try { path = new URL(req.url, 'http://localhost').pathname; }
    catch { res.writeHead(400, securityHeaders); res.end('Bad request'); return; }
    if (path === '/api/health' && req.method === 'GET') {
      json(res, 200, { app: 'coin-journal', ready: true }); return;
    }
    if (path.startsWith('/api/')) {
      // Account information is available only to the local app. No public account API or CORS.
      const address = req.socket.remoteAddress;
      const host = req.headers.host || '';
      const localHost = /^(localhost|127\.0\.0\.1)(:\d+)?$/.test(host);
      const origin = req.headers.origin;
      if (!['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(address) || !localHost
        || req.headers['x-coin-journal'] !== '1' || (origin && origin !== `http://${host}`)
        || (req.headers['sec-fetch-site'] && req.headers['sec-fetch-site'] !== 'same-origin')) {
        json(res, 403, { code: 'LOCAL_APP_ONLY', message: '계정 정보는 로컬 앱에서만 조회할 수 있습니다.' }); return;
      }
      if (path === '/api/okx/status' && req.method === 'GET') { json(res, 200, okx.status()); return; }
      if (path !== '/api/okx/snapshot' || req.method !== 'POST') { json(res, 404, { message: '지원하지 않는 요청입니다.' }); return; }
      try { json(res, 200, await okx.snapshot()); }
      catch (error) {
        const known = error instanceof OkxError;
        json(res, known ? error.status : 500, { code: known ? error.code : 'INTERNAL_ERROR', message: known ? error.message : '계정 조회를 처리하지 못했습니다.' });
      }
      return;
    }
    const file = Object.hasOwn(files, path) ? files[path] : null;
    if (!file || !['GET', 'HEAD'].includes(req.method)) { res.writeHead(404, securityHeaders); res.end('Not found'); return; }
    try {
      const data = await readFile(new URL(`./public/${file}`, import.meta.url));
      res.writeHead(200, { ...securityHeaders, 'Content-Type': types[file.split('.').pop()], 'Cache-Control': 'no-cache' });
      res.end(req.method === 'HEAD' ? undefined : data);
    } catch { res.writeHead(500, securityHeaders); res.end('Unable to load application'); }
  });
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const port = Number(process.env.PORT || 3000);
  const server = createApp();
  server.on('error', () => { console.error('서버를 시작할 수 없습니다. 포트 사용 여부와 실행 권한을 확인하세요.'); process.exitCode = 1; });
  server.listen(port, '127.0.0.1', () => console.log(`Coin Journal: http://127.0.0.1:${port} (local only)`));
}
