﻿$ErrorActionPreference = 'Continue'
$AppRoot = Split-Path -Parent $PSScriptRoot
$StateRoot = Join-Path $env:LOCALAPPDATA 'CoinJournal'
Write-Host 'Coin Journal - startup diagnostics (no API keys are displayed)'
Write-Host "PowerShell version: $($PSVersionTable.PSVersion)"
Write-Host "Windows process architecture: $env:PROCESSOR_ARCHITECTURE"
Write-Host "Application folder: $AppRoot"
$Bundled = Join-Path $AppRoot 'runtime/node.exe'
Write-Host "Bundled Node present: $(Test-Path $Bundled)"
if (Test-Path $Bundled) { & $Bundled --version }
Write-Host "Server entry present: $(Test-Path (Join-Path $AppRoot 'server.js'))"
try {
    $Health = Invoke-RestMethod 'http://127.0.0.1:3000/api/health' -TimeoutSec 2
    Write-Host "Coin Journal server ready: $($Health.app -eq 'coin-journal' -and $Health.ready)"
} catch { Write-Host 'Coin Journal server is not ready on port 3000.' }
foreach ($Name in @('startup-error.txt', 'server-3000-error.log')) {
    $Log = Join-Path $StateRoot $Name
    if (Test-Path $Log) {
        Write-Host "Error report: $Name"
        Get-Content -Encoding UTF8 $Log -Tail 12
    }
}
Write-Host 'Do not share credentials.json or API credentials.'
