﻿[CmdletBinding()]
param(
    [switch]$Configure,
    [switch]$SkipCredentialPrompt,
    [switch]$NoBrowser,
    [ValidateRange(1024, 65535)][int]$Port = 3000
)

$ErrorActionPreference = 'Stop'
$AppRoot = Split-Path -Parent $PSScriptRoot
$DataRoot = if ($env:LOCALAPPDATA) { $env:LOCALAPPDATA } else { [Environment]::GetFolderPath('LocalApplicationData') }
$StateRoot = Join-Path $DataRoot 'CoinJournal'
$CredentialFile = Join-Path $StateRoot 'credentials.json'
$ProcessFile = Join-Path $StateRoot "server-$Port.json"
$ServerUrl = "http://127.0.0.1:$Port"
$BundledNode = Join-Path $AppRoot 'runtime/node.exe'
$OnWindows = $env:OS -eq 'Windows_NT'

function Write-Stage([string]$Message) {
    Write-Host $Message
    Add-Content -Encoding UTF8 -Path (Join-Path $StateRoot 'launcher.log') -Value ("{0:o} {1}" -f [DateTime]::Now, $Message)
}

function Show-Message([string]$Message) {
    Write-Host $Message -ForegroundColor Yellow
    if ($OnWindows -and -not $NoBrowser) {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show($Message, 'Coin Journal') | Out-Null
    }
}

function Convert-ToPlainText([Security.SecureString]$Value) {
    $Pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Value)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($Pointer) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($Pointer) }
}

function Show-CredentialDialog {
    if (-not $OnWindows) { throw 'Windows is required for the encrypted credential dialog.' }
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $Form = New-Object System.Windows.Forms.Form
    $Form.Text = 'Coin Journal - OKX 계정 설정'
    $Form.ClientSize = New-Object System.Drawing.Size(540, 350)
    $Form.StartPosition = 'CenterScreen'
    $Form.FormBorderStyle = 'FixedDialog'
    $Form.MaximizeBox = $false
    $Form.MinimizeBox = $false
    $Form.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $Intro = New-Object System.Windows.Forms.Label
    $Intro.Location = New-Object System.Drawing.Point(20, 20)
    $Intro.Size = New-Object System.Drawing.Size(500, 50)
    $Intro.Text = "OKX Read 전용 키를 입력하세요. Windows 계정으로 암호화합니다.`n'나중에'를 누르면 매매일지부터 사용할 수 있습니다."
    $Form.Controls.Add($Intro)
    $Inputs = @()
    $Names = @('API Key', 'Secret Key', 'Passphrase')
    for ($Index = 0; $Index -lt 3; $Index++) {
        $Label = New-Object System.Windows.Forms.Label
        $Label.Text = $Names[$Index]
        $Label.Location = New-Object System.Drawing.Point(20, (86 + $Index * 47))
        $Label.Size = New-Object System.Drawing.Size(110, 25)
        $InputBox = New-Object System.Windows.Forms.TextBox
        $InputBox.Location = New-Object System.Drawing.Point(135, (82 + $Index * 47))
        $InputBox.Size = New-Object System.Drawing.Size(380, 28)
        $InputBox.UseSystemPasswordChar = $true
        $Form.Controls.Add($Label)
        $Form.Controls.Add($InputBox)
        $Inputs += $InputBox
    }
    $DemoCheck = New-Object System.Windows.Forms.CheckBox
    $DemoCheck.Text = 'OKX 모의거래용 API 키'
    $DemoCheck.Location = New-Object System.Drawing.Point(135, 226)
    $DemoCheck.Size = New-Object System.Drawing.Size(350, 25)
    $Form.Controls.Add($DemoCheck)
    $Save = New-Object System.Windows.Forms.Button
    $Save.Text = '저장하고 시작'
    $Save.Location = New-Object System.Drawing.Point(245, 282)
    $Save.Size = New-Object System.Drawing.Size(145, 35)
    $Later = New-Object System.Windows.Forms.Button
    $Later.Text = '나중에'
    $Later.Location = New-Object System.Drawing.Point(400, 282)
    $Later.Size = New-Object System.Drawing.Size(115, 35)
    $Later.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $Form.Controls.Add($Save)
    $Form.Controls.Add($Later)
    $Form.AcceptButton = $Save
    $Form.CancelButton = $Later
    $Save.Add_Click({
        if (@($Inputs | Where-Object { [string]::IsNullOrWhiteSpace($_.Text) }).Count -gt 0) {
            [System.Windows.Forms.MessageBox]::Show('세 값을 모두 입력하거나 나중에를 선택하세요.', 'Coin Journal') | Out-Null
            return
        }
        try {
            $Stored = @{
                apiKey = ConvertFrom-SecureString (ConvertTo-SecureString $Inputs[0].Text -AsPlainText -Force)
                apiSecret = ConvertFrom-SecureString (ConvertTo-SecureString $Inputs[1].Text -AsPlainText -Force)
                passphrase = ConvertFrom-SecureString (ConvertTo-SecureString $Inputs[2].Text -AsPlainText -Force)
                demo = [bool]$DemoCheck.Checked
            }
            $Stored | ConvertTo-Json | Set-Content -Encoding UTF8 -Path $CredentialFile
            $Form.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $Form.Close()
        } catch {
            [System.Windows.Forms.MessageBox]::Show('인증 정보를 암호화해 저장하지 못했습니다. 저장 폴더 권한을 확인하세요.', 'Coin Journal') | Out-Null
        }
    })
    try { return $Form.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK }
    finally {
        foreach ($InputBox in $Inputs) { $InputBox.Clear() }
        $Form.Dispose()
    }
}

function Load-Credentials {
    $Stored = Get-Content -Raw -Encoding UTF8 -Path $CredentialFile | ConvertFrom-Json
    return @{
        apiKey = Convert-ToPlainText (ConvertTo-SecureString $Stored.apiKey)
        apiSecret = Convert-ToPlainText (ConvertTo-SecureString $Stored.apiSecret)
        passphrase = Convert-ToPlainText (ConvertTo-SecureString $Stored.passphrase)
        demo = if ($Stored.demo -eq $true) { 'true' } else { 'false' }
    }
}

function Test-CoinJournalServer {
    try {
        $Response = Invoke-RestMethod -Uri "$ServerUrl/api/health" -TimeoutSec 2
        return $Response.app -eq 'coin-journal' -and $Response.ready -eq $true
    } catch { return $false }
}

function Stop-OwnedServer {
    if (-not (Test-Path $ProcessFile)) { return }
    try {
        $Saved = Get-Content -Raw -Encoding UTF8 $ProcessFile | ConvertFrom-Json
        $Process = Get-Process -Id $Saved.pid -ErrorAction Stop
        # PID reuse must never terminate an unrelated process.
        if ($Process.Path -eq $Saved.path -and $Process.StartTime.ToUniversalTime().Ticks.ToString() -eq $Saved.startTicks) {
            Stop-Process -Id $Process.Id -ErrorAction Stop
            $Process.WaitForExit(5000) | Out-Null
        }
    } catch { }
}

try {
    New-Item -ItemType Directory -Force -Path $StateRoot | Out-Null
    Write-Stage '[1/4] Checking application files...'
    if (-not (Test-Path (Join-Path $AppRoot 'server.js'))) { throw 'Application files are missing. Extract the whole ZIP before running START.cmd.' }
    $NodePath = if (Test-Path $BundledNode) { $BundledNode } else { (Get-Command node -ErrorAction Stop).Source }
    $VersionText = & $NodePath --version
    if ($LASTEXITCODE -ne 0 -or $VersionText -notmatch '^v(\d+)\.(\d+)\.') { throw 'The Node.js runtime cannot start. Use the complete Windows x64 portable package.' }
    if ([int]$Matches[1] -lt 24 -or ([int]$Matches[1] -eq 24 -and [int]$Matches[2] -lt 5)) { throw 'Node.js 24.5 or later is required.' }

    Write-Stage '[2/4] Preparing account settings...'
    $SavedNow = $false
    if ($Configure -or (-not $SkipCredentialPrompt -and -not (Test-Path $CredentialFile) -and -not $env:OKX_API_KEY)) {
        $SavedNow = Show-CredentialDialog
        if ($SavedNow) { Stop-OwnedServer }
    }
    $Credentials = $null
    if (Test-Path $CredentialFile) {
        try { $Credentials = Load-Credentials }
        catch { Show-Message '저장된 키를 이 Windows 계정에서 열 수 없습니다. 앱은 키 없이 열립니다. SETUP-OKX.cmd에서 다시 등록할 수 있습니다.' }
    }

    Write-Stage '[3/4] Starting the local application...'
    if (-not (Test-CoinJournalServer)) {
        $Previous = @{}
        foreach ($Name in @('OKX_API_KEY', 'OKX_API_SECRET', 'OKX_API_PASSPHRASE', 'OKX_DEMO', 'PORT')) {
            $Previous[$Name] = [Environment]::GetEnvironmentVariable($Name, 'Process')
        }
        try {
            $env:PORT = "$Port"
            if ($Credentials) {
                $env:OKX_API_KEY = $Credentials.apiKey
                $env:OKX_API_SECRET = $Credentials.apiSecret
                $env:OKX_API_PASSPHRASE = $Credentials.passphrase
                $env:OKX_DEMO = $Credentials.demo
            }
            $Options = @{
                FilePath = $NodePath
                ArgumentList = @('--use-env-proxy', 'server.js')
                WorkingDirectory = $AppRoot
                RedirectStandardOutput = Join-Path $StateRoot "server-$Port.log"
                RedirectStandardError = Join-Path $StateRoot "server-$Port-error.log"
                PassThru = $true
            }
            if ($OnWindows) { $Options.WindowStyle = 'Hidden' }
            $Child = Start-Process @Options
            $StartTicks = $Child.StartTime.ToUniversalTime().Ticks.ToString()
            $Ready = $false
            for ($Attempt = 0; $Attempt -lt 40; $Attempt++) {
                if ($Child.HasExited) { break }
                if (Test-CoinJournalServer) { $Ready = $true; break }
                Start-Sleep -Milliseconds 250
            }
            if (-not $Ready) { throw "The local server did not start. Port $Port may be in use. Run DIAGNOSE.cmd to see the error." }
            @{ pid = $Child.Id; path = $NodePath; startTicks = $StartTicks } | ConvertTo-Json | Set-Content -Encoding UTF8 $ProcessFile
        } finally {
            foreach ($Name in $Previous.Keys) { [Environment]::SetEnvironmentVariable($Name, $Previous[$Name], 'Process') }
            if ($Credentials) { $Credentials.Clear() }
        }
    } elseif ($SavedNow) {
        Show-Message '기존 서버가 다른 실행기로 시작되어 자동 재시작하지 않았습니다. 기존 Coin Journal 서버를 종료한 뒤 START.cmd를 다시 실행하세요.'
    }

    Write-Stage "[4/4] Ready: $ServerUrl"
    if (-not $NoBrowser) { Start-Process $ServerUrl }
    exit 0
} catch {
    # No environment dump, credential contents, or PowerShell transcript.
    $Message = $_.Exception.Message
    Write-Host "STARTUP ERROR: $Message" -ForegroundColor Red
    if (Test-Path $StateRoot) {
        Set-Content -Encoding UTF8 -Path (Join-Path $StateRoot 'startup-error.txt') -Value $Message
    }
    Show-Message "$Message`n`n진단: DIAGNOSE.cmd를 실행하세요."
    exit 1
}
