import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createOkxClient, signature, OkxError } from '../lib/okx.js';

// Deliberately fake credentials and fixtures. No test makes a network request.
const env = { OKX_API_KEY: 'fixture-key', OKX_API_SECRET: 'fixture-secret', OKX_API_PASSPHRASE: 'fixture-passphrase', OKX_DEMO: 'false' };
const baseTime = Date.parse('2026-11-02T00:00:00.000Z');
const balance = [{ totalEq: '1250.5', details: [
  { ccy: 'USDT', eq: '1000', cashBal: '1000', availBal: '750', eqUsd: '1000', privateField: 'not-for-browser' },
  { ccy: 'BTC', eq: '0.0025', cashBal: '0.0025', availBal: '0.002', eqUsd: '250.5' },
  { ccy: 'ETH', eq: '0', cashBal: '0', availBal: '0', eqUsd: '0' },
] }];
const positions = [{ instId: 'BTC-USDT-SWAP', instType: 'SWAP', posSide: 'long', pos: '2', avgPx: '95000', markPx: '96000', upl: '20', uplRatio: '0.1', ccy: '', lever: '3', mgnMode: 'cross', liqPx: '65000', privateField: 'not-for-browser' }, { pos: '0' }];
function fixture({ permissions = 'read_only', vars = env, failure } = {}) {
  const calls = [];
  let time = baseTime;
  const client = createOkxClient({ env: vars, now: () => time, fetchImpl: async (url, options) => {
    calls.push({ url, options });
    assert.equal(options.method, 'GET');
    assert.equal(options.redirect, 'error');
    const path = new URL(url).pathname;
    let data = path.endsWith('/time') ? [{ ts: String(baseTime + 4000) }] : path.endsWith('/config') ? [{ perm: permissions, uid: 'not-for-browser' }] : path.endsWith('/balance') ? balance : positions;
    return new Response(JSON.stringify(failure && !path.endsWith('/time') ? failure : { code: '0', data }));
  } });
  return { client, calls, advance: ms => { time += ms; } };
}

test('OKX signature matches independent HMAC-SHA256 fixture and rejects order paths', () => {
  assert.equal(signature('2026-11-02T00:00:00.000Z', '/api/v5/account/balance', 'fixture-secret'), 'dvihXMKsS/jfK0QGZdKZAxpnl7fc3nF+98NGJ7obB7M=');
  assert.throws(() => signature('timestamp', '/api/v5/trade/order', 'fixture-secret'));
});

test('missing credentials return status names only and never send a request', async () => {
  const { client, calls } = fixture({ vars: {} });
  assert.deepEqual(client.status().missing, ['OKX_API_KEY', 'OKX_API_SECRET', 'OKX_API_PASSPHRASE']);
  await assert.rejects(client.snapshot(), error => error.code === 'OKX_NOT_CONFIGURED');
  assert.equal(calls.length, 0);
  assert.ok(!JSON.stringify(client.status()).includes('fixture-secret'));
});

test('read-only snapshot signs GETs with OKX time, normalizes currencies and excludes private fields', async () => {
  const { client, calls } = fixture();
  const result = await client.snapshot();
  assert.equal(result.mode, 'live');
  assert.equal(result.totalEquityUsd, '1250.5');
  assert.equal(result.balances.length, 2);
  assert.equal(result.balances[1].equity, '0.0025');
  assert.equal(result.positions.length, 1);
  assert.equal(result.positions[0].size, '2');
  assert.equal(result.positions[0].settlementCurrency, 'USDT');
  assert.equal(result.positions[0].marginMode, 'cross');
  assert.equal(result.positions[0].liquidationPrice, '65000');
  assert.equal(result.positions[0].unrealizedPnlRatio, '0.1');
  assert.ok(!JSON.stringify(result).includes('not-for-browser'));
  assert.ok(!JSON.stringify(result).includes('fixture-'));
  assert.equal(calls.length, 4);
  for (const { url, options } of calls.slice(1)) {
    assert.equal(new URL(url).origin, 'https://www.okx.com');
    assert.equal(options.headers['OK-ACCESS-TIMESTAMP'], '2026-11-02T00:00:04.000Z');
    assert.equal(options.headers['OK-ACCESS-KEY'], 'fixture-key');
    assert.equal(options.headers['OK-ACCESS-SIGN'], signature(options.headers['OK-ACCESS-TIMESTAMP'], new URL(url).pathname, 'fixture-secret'));
    assert.equal(options.headers['x-simulated-trading'], undefined);
  }
});

test('keys with trading/withdrawal or unverifiable permissions are refused before balances are fetched', async () => {
  for (const permissions of ['read_only,trade', 'read_only,withdraw', '']) {
    const { client, calls } = fixture({ permissions });
    await assert.rejects(client.snapshot(), error => error.code === 'OKX_READ_ONLY_REQUIRED');
    assert.equal(calls.length, 2);
  }
});

test('OKX demo keys use simulated-trading header and response indicates demo', async () => {
  const { client, calls } = fixture({ vars: { ...env, OKX_DEMO: 'true' } });
  assert.equal((await client.snapshot()).mode, 'demo');
  assert.ok(calls.slice(1).every(call => call.options.headers['x-simulated-trading'] === '1'));
});

test('concurrent refreshes coalesce and successful results cache for only ten seconds', async () => {
  const { client, calls, advance } = fixture();
  const [a, b] = await Promise.all([client.snapshot(), client.snapshot()]);
  assert.deepEqual(a, b);
  assert.equal(calls.length, 4);
  await client.snapshot();
  assert.equal(calls.length, 4);
  advance(10001);
  await client.snapshot();
  assert.equal(calls.length, 8);
});

test('upstream errors are sanitized, no raw message or credentials returned', async () => {
  const { client } = fixture({ failure: { code: '50113', msg: 'fixture-secret raw failure', data: [] } });
  await assert.rejects(client.snapshot(), error => error instanceof OkxError && error.code === 'OKX_50113' && !error.message.includes('fixture-secret'));
  const network = createOkxClient({ env, fetchImpl: async () => { throw Error('fixture-secret'); } });
  await assert.rejects(network.snapshot(), error => error.code === 'OKX_NETWORK' && !error.message.includes('fixture-secret'));
});
