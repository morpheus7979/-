import {test} from 'node:test';
import assert from 'node:assert/strict';
import {position,profit} from '../public/finance.js';
test('long risk sizing and required capital',()=>{assert.deepEqual(position({capital:10000000,risk:1,entry:100000000,stop:95000000,side:'long'}),{loss:100000,quantity:0.02,notional:2000000});});
test('short sizing and invalid stop direction',()=>{assert.equal(position({capital:1000,risk:2,entry:100,stop:110,side:'short'}).quantity,2);assert.throws(()=>position({capital:1000,risk:2,entry:100,stop:110,side:'long'}));assert.throws(()=>position({capital:0,risk:2,entry:100,stop:90,side:'long'}));});
test('realized profit subtracts fees in both directions; open positions excluded',()=>{const t={entry:100,exit:120,quantity:2,fee:3,side:'long'};assert.equal(profit(t),37);assert.equal(profit({...t,side:'short'}),-43);assert.equal(profit({...t,exit:null}),null);});
