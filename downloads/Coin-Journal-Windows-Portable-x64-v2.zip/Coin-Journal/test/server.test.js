import { test } from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import http from 'node:http';
import { createApp } from '../server.js';

async function withServer(fn) {
  let snapshots = 0;
  const app = createApp({ okx: {
    status: () => ({ configured: true, missing: [], mode: 'live', readOnly: true, validMode: true }),
    snapshot: async () => { snapshots++; return { totalEquityUsd: '1250.5', mode: 'live', balances: [], positions: [] }; },
  } });
  app.listen(0, '127.0.0.1');
  await once(app, 'listening');
  const url = `http://127.0.0.1:${app.address().port}`;
  try { await fn({ url, snapshots: () => snapshots }); }
  finally { app.closeAllConnections(); await new Promise(resolve => app.close(resolve)); }
}

test('launcher health check succeeds without credentials and never requests OKX', async () => {
  await withServer(async ({ url, snapshots }) => {
    const response = await fetch(`${url}/api/health`);
    assert.equal(response.status, 200);
    assert.deepEqual(await response.json(), { app: 'coin-journal', ready: true });
    assert.equal(snapshots(), 0);
  });
});

test('local OKX API requires app header and rejects cross-origin calls and order routes', async () => {
  await withServer(async ({ url, snapshots }) => {
    const headers = { 'X-Coin-Journal': '1', Origin: url };
    assert.equal((await fetch(`${url}/api/okx/status`)).status, 403);
    assert.equal((await fetch(`${url}/api/okx/status`, { headers: { ...headers, Origin: 'https://untrusted.example' } })).status, 403);
    assert.equal((await fetch(`${url}/api/okx/status`, { headers: { ...headers, 'Sec-Fetch-Site': 'cross-site' } })).status, 403);
    const status = await fetch(`${url}/api/okx/status`, { headers });
    assert.equal(status.status, 200);
    assert.equal(status.headers.get('cache-control'), 'no-store');
    assert.equal((await status.json()).configured, true);
    assert.equal((await fetch(`${url}/api/okx/snapshot`, { headers })).status, 404);
    assert.equal((await fetch(`${url}/api/okx/order`, { headers, method: 'POST' })).status, 404);
    assert.equal(snapshots(), 0);
    const response = await fetch(`${url}/api/okx/snapshot`, { headers, method: 'POST' });
    assert.equal(response.status, 200);
    assert.equal((await response.json()).totalEquityUsd, '1250.5');
    assert.equal(snapshots(), 1);
  });
});

test('host validation blocks DNS rebinding and static routes never expose local credential files', async () => {
  await withServer(async ({ url }) => {
    const rejected = await new Promise((resolve, reject) => {
      http.get(`${url}/api/okx/status`, { headers: { Host: 'untrusted.example', 'X-Coin-Journal': '1' } }, response => { response.resume(); resolve(response.statusCode); }).on('error', reject);
    });
    assert.equal(rejected, 403);
    for (const path of ['/.env.local', '/lib/okx.js', '/__proto__', '/api/okx/credentials']) assert.ok([403, 404].includes((await fetch(url + path)).status));
    const home = await fetch(url);
    assert.equal(home.status, 200);
    assert.ok(home.headers.get('content-security-policy').includes("connect-src 'self'"));
    assert.ok((await home.text()).includes('내 OKX 계정'));
  });
});
