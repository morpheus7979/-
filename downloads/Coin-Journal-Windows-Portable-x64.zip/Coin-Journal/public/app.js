import { position, profit } from './finance.js';
import { initOkx } from './okx-ui.js';

const $ = selector => document.querySelector(selector);
const key = 'coin-journal-v1';
const won = value => new Intl.NumberFormat('ko-KR', { style: 'currency', currency: 'KRW', maximumFractionDigits: 0 }).format(value);
const number = value => new Intl.NumberFormat('ko-KR', { maximumFractionDigits: 8 }).format(value);
const svgNS = 'http://www.w3.org/2000/svg';
let trades = [];
let storageReadable = true;
let demo = new URLSearchParams(location.search).get('demo') === '1';
let filter = 'all';
let selectedId = null;
let toastTimer;

function dateString(date) {
  return new Intl.DateTimeFormat('sv-SE', { timeZone: 'Asia/Seoul', year: 'numeric', month: '2-digit', day: '2-digit' }).format(date);
}

function isTrade(trade) {
  return trade && typeof trade.id === 'string' && typeof trade.symbol === 'string'
    && typeof trade.date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(trade.date)
    && typeof trade.note === 'string' && ['long', 'short'].includes(trade.side)
    && [trade.entry, trade.quantity].every(value => Number.isFinite(value) && value > 0)
    && Number.isFinite(trade.fee) && trade.fee >= 0
    && (trade.exit === null || (Number.isFinite(trade.exit) && trade.exit > 0))
    && (profit(trade) === null || Number.isFinite(profit(trade)));
}

try {
  const saved = JSON.parse(localStorage.getItem(key) || '[]');
  if (!Array.isArray(saved) || !saved.every(isTrade)) throw Error('Invalid records');
  trades = saved;
} catch {
  storageReadable = false;
}

let demoTrades = [
  { symbol: 'BTC', side: 'long', entry: 94000000, exit: 98000000, quantity: 0.08, fee: 7680, note: '예시 기록: 지지선 확인 후 분할 진입. 목표 구간에서 계획대로 청산했습니다.' },
  { symbol: 'ETH', side: 'long', entry: 3600000, exit: 3500000, quantity: 0.8, fee: 2840, note: '예시 기록: 손절 기준에 따라 종료. 다음에는 거래량 확인 후 진입하기.' },
  { symbol: 'SOL', side: 'short', entry: 240000, exit: 225000, quantity: 8, fee: 1860, note: '예시 기록: 저항 구간에서 숏 진입. 정해둔 목표가에 청산했습니다.' },
  { symbol: 'BTC', side: 'long', entry: 96500000, exit: 101000000, quantity: 0.05, fee: 4938, note: '예시 기록: 추세 전환 확인 후 진입. 매수 근거를 복기합니다.' },
  { symbol: 'ETH', side: 'long', entry: 3650000, exit: null, quantity: 1.2, fee: 2190, note: '예시 기록: 진행 중 거래입니다. 손절 기준과 목표 구간을 관찰합니다.' },
].map((trade, index) => ({ ...trade, id: `demo-${index}`, date: dateString(new Date(Date.now() - (6 - index) * 86400000)) }));

$('#today').textContent = new Intl.DateTimeFormat('ko-KR', { timeZone: 'Asia/Seoul', year: 'numeric', month: 'long', day: 'numeric', weekday: 'short' }).format(new Date());
$('#journal [name=date]').value = dateString(new Date());

function records() { return demo ? demoTrades : trades; }

function toast(message) {
  clearTimeout(toastTimer);
  $('#toast').textContent = message;
  $('#toast').hidden = false;
  toastTimer = setTimeout(() => { $('#toast').hidden = true; }, 4000);
}

function persist(next) {
  if (demo) {
    demoTrades = next;
    render();
    return true;
  }
  if (!storageReadable) {
    toast('기존 기록을 읽을 수 없어 저장을 중단했습니다. 브라우저 저장 공간을 확인하세요.');
    return false;
  }
  try {
    localStorage.setItem(key, JSON.stringify(next));
    trades = next;
    render();
    return true;
  } catch {
    toast('저장하지 못했습니다. 브라우저 저장 공간과 권한을 확인하세요.');
    return false;
  }
}

function element(tag, text, className) {
  const node = document.createElement(tag);
  if (text !== undefined) node.textContent = text;
  if (className) node.className = className;
  return node;
}

function svgElement(tag, attrs) {
  const node = document.createElementNS(svgNS, tag);
  for (const [name, value] of Object.entries(attrs)) node.setAttribute(name, value);
  return node;
}

function renderChart(closed) {
  const container = $('#chart');
  container.replaceChildren();
  const width = Math.max(container.clientWidth, 250);
  const svg = svgElement('svg', { viewBox: `0 0 ${width} 150`, preserveAspectRatio: 'none', role: 'img', 'aria-label': closed.length ? '거래일별 누적 실현 손익. 수수료가 포함됩니다.' : '아직 종료한 거래가 없습니다.' });
  for (const y of [16, 53, 90, 127]) svg.append(svgElement('line', { x1: 0, y1: y, x2: width, y2: y, class: 'grid-line' }));
  if (closed.length) {
    const daily = new Map();
    for (const trade of [...closed].sort((a, b) => a.date.localeCompare(b.date))) daily.set(trade.date, (daily.get(trade.date) || 0) + profit(trade));
    let cumulative = 0;
    const points = [{ date: '', value: 0 }, ...[...daily].map(([date, value]) => ({ date, value: cumulative += value }))];
    const min = Math.min(...points.map(p => p.value), 0);
    const max = Math.max(...points.map(p => p.value), 0);
    const range = max - min || 1;
    const coordinates = points.map((p, i) => [8 + i / (points.length - 1) * (width - 16), 114 - (p.value - min) / range * 100]);
    const path = coordinates.map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(2)},${y.toFixed(2)}`).join(' ');
    const defs = svgElement('defs', {});
    const gradient = svgElement('linearGradient', { id: 'chart-fill', x1: '0', y1: '0', x2: '0', y2: '1' });
    gradient.append(svgElement('stop', { offset: '0%', 'stop-color': '#c8df9c', 'stop-opacity': '.19' }), svgElement('stop', { offset: '100%', 'stop-color': '#c8df9c', 'stop-opacity': '0' }));
    defs.append(gradient);
    svg.append(defs, svgElement('path', { d: `${path} L${width - 8},128 L8,128 Z`, fill: 'url(#chart-fill)', stroke: 'none' }), svgElement('path', { d: path, class: 'chart-line' }));
    const end = coordinates.at(-1);
    svg.append(svgElement('circle', { cx: end[0], cy: end[1], r: 7, fill: '#c8df9c', 'fill-opacity': '.14', stroke: 'none' }), svgElement('circle', { cx: end[0], cy: end[1], r: 3, fill: '#d6e9b5', stroke: '#234e3f', 'stroke-width': '1.5' }));
    const datePoints = points.slice(1);
    const labelIndexes = [...new Set([0, Math.floor((datePoints.length - 1) / 2), datePoints.length - 1])];
    for (const index of labelIndexes) {
      const text = svgElement('text', { x: coordinates[index + 1][0], y: 147, 'text-anchor': index === datePoints.length - 1 ? 'end' : 'middle' });
      text.textContent = datePoints[index].date.slice(5).replace('-', '.');
      svg.append(text);
    }
  }
  container.append(svg);
  if (!closed.length) {
    const empty = element('div', undefined, 'chart-empty');
    empty.append(element('strong', '나의 투자 이야기는 이제 시작입니다'), element('span', '종료한 거래를 기록하면 손익 흐름이 표시됩니다.'));
    container.append(empty);
  }
}

function render() {
  const all = records();
  const closed = all.filter(trade => trade.exit !== null);
  const pnl = closed.reduce((sum, trade) => sum + profit(trade), 0);
  $('#pnl').textContent = won(pnl);
  $('#pnl').className = pnl < 0 ? 'negative' : 'positive';
  $('#chart-total').textContent = won(pnl);
  for (const [selector, count] of [['#total', all.length], ['#open', all.length - closed.length]]) {
    $(selector).replaceChildren(document.createTextNode(number(count)), element('small', '건'));
  }
  $('#closed-count').textContent = `종료 거래 ${closed.length}건`;
  $('#win').textContent = closed.length ? `${Math.round(closed.filter(trade => profit(trade) > 0).length / closed.length * 100)}%` : '—';
  $('#record-count').textContent = all.length;
  document.body.classList.toggle('demo-active', demo);
  $('#demo-toggle').setAttribute('aria-pressed', String(demo));
  $('#demo-toggle').textContent = demo ? '내 실제 기록으로 돌아가기 ↗' : '예시 데이터로 둘러보기 ↗';
  $('#mode-note').replaceChildren(document.createTextNode(demo ? '예시 데이터 · 실제 기록에 저장되지 않습니다' : '나의 투자 기록'), ...(!demo ? [element('span', '· 모든 금액은 원화 기준', 'subtle')] : []));
  $('#save-status').textContent = !demo && !storageReadable ? '기존 기록을 읽을 수 없습니다. 저장 공간을 확인하세요. 기존 데이터는 변경하지 않았습니다.' : '';
  $('#journal button[type=submit]').disabled = !demo && !storageReadable;
  renderChart(closed);
  const query = $('#search').value.trim().toLowerCase();
  const filtered = all.filter(trade => trade.symbol.toLowerCase().includes(query) && (filter === 'all' || (filter === 'open' ? trade.exit === null : trade.exit !== null)));
  $('#trades').replaceChildren();
  for (const trade of [...filtered].sort((a, b) => b.date.localeCompare(a.date))) {
    const row = element('tr');
    const coin = element('div', undefined, 'coin-cell');
    const symbol = trade.symbol.toLowerCase();
    const coinClass = ['btc', 'eth', 'sol'].includes(symbol) ? symbol : 'other';
    const glyph = { btc: '₿', eth: 'Ξ', sol: '◎' }[symbol] || trade.symbol.slice(0, 1);
    const name = element('div');
    name.append(element('strong', trade.symbol), element('small', trade.date.replaceAll('-', '.')));
    coin.append(element('span', glyph, `coin-avatar ${coinClass}`), name);
    const coinCell = element('td');
    coinCell.append(coin);
    const side = element('td');
    side.append(element('span', trade.side === 'long' ? '↗ 롱' : '↘ 숏', `side-tag ${trade.side}`));
    const entry = element('td', won(trade.entry));
    entry.append(element('small', `${number(trade.quantity)}개`));
    const value = profit(trade);
    const pnlCell = element('td', undefined, 'pnl-cell');
    pnlCell.append(value === null ? element('span', '● 진행 중', 'open-tag') : element('span', `${value > 0 ? '+' : ''}${won(value)}`, value < 0 ? 'negative' : 'positive'));
    const action = element('td');
    const button = element('button', '↗', 'detail-button');
    button.setAttribute('aria-label', `${trade.symbol} ${trade.date} 거래 상세`);
    button.onclick = () => showDetail(trade);
    action.append(button);
    row.append(coinCell, side, entry, pnlCell, action);
    $('#trades').append(row);
  }
  $('#empty').hidden = filtered.length > 0;
  $('#empty h3').textContent = all.length ? '조건에 맞는 거래가 없습니다' : '첫 거래를 기록해 보세요';
  $('#empty p').textContent = all.length ? '검색어 또는 거래 상태 필터를 바꿔보세요.' : '투자의 이유를 남기면, 나만의 기준이 생깁니다.';
  $('#empty [data-new-trade]').hidden = all.length > 0;
  $('#visible-count').textContent = `${filtered.length}개의 거래 기록`;
}

function showDetail(trade) {
  selectedId = trade.id;
  $('#detail-title').textContent = `${trade.symbol} · 거래 상세`;
  const details = [
    ['거래 날짜', trade.date], ['포지션', trade.side === 'long' ? '롱' : '숏'],
    ['진입가', won(trade.entry)], ['수량', `${number(trade.quantity)}개`],
    ['청산가', trade.exit === null ? '진행 중' : won(trade.exit)], ['총 수수료', won(trade.fee)],
    ['실현 손익', trade.exit === null ? '미실현' : won(profit(trade))], ['매매 이유와 복기', trade.note || '기록한 메모가 없습니다.'],
  ];
  $('#trade-detail').replaceChildren(...details.flatMap(([label, value]) => [element('dt', label), element('dd', value)]));
  $('#detail-dialog').showModal();
}

$('#calculator').onsubmit = event => {
  event.preventDefault();
  const form = new FormData(event.target);
  const result = $('#calculation');
  try {
    const input = Object.fromEntries([...form].map(([name, value]) => [name, name === 'side' ? value : Number(value)]));
    const calculated = position(input);
    if (!Object.values(calculated).every(Number.isFinite)) throw Error('계산 가능한 범위의 금액을 입력해 주세요.');
    result.classList.remove('error');
    const quantity = element('strong', number(calculated.quantity));
    quantity.append(element('small', '개'));
    const details = element('div', undefined, 'result-details');
    const loss = element('div', '허용 손실');
    loss.append(element('strong', won(calculated.loss)));
    const order = element('div', '예상 주문 금액');
    order.append(element('strong', won(calculated.notional)));
    details.append(loss, order);
    result.replaceChildren(element('span', '나의 적정 포지션 수량', 'result-label'), quantity, details);
    if (calculated.notional > input.capital) result.append(element('p', '주문 금액이 투자금을 초과합니다. 현물 거래에서는 수량을 줄이세요.', 'warning'));
  } catch (error) {
    result.classList.add('error');
    result.textContent = error.message;
  }
};

for (const button of document.querySelectorAll('[data-new-trade]')) {
  button.onclick = () => {
    $('#form-mode-note').textContent = demo ? '예시 모드입니다. 추가한 기록은 실제 데이터에 저장되지 않습니다.' : '오늘의 판단을 내일의 경험으로 남겨보세요. 금액은 원화 기준입니다.';
    $('#trade-dialog').showModal();
  };
}
$('#close-dialog').onclick = () => $('#trade-dialog').close();
$('#close-detail').onclick = () => $('#detail-dialog').close();

$('#journal').onsubmit = event => {
  event.preventDefault();
  const form = new FormData(event.target);
  const trade = {
    id: crypto.randomUUID(), symbol: form.get('symbol').trim().toUpperCase(), date: form.get('date'), side: form.get('side'),
    quantity: Number(form.get('quantity')), entry: Number(form.get('entry')),
    exit: form.get('exit') === '' ? null : Number(form.get('exit')),
    fee: Number(form.get('fee')), note: form.get('note').trim(),
  };
  if (!isTrade(trade) || !trade.symbol) {
    $('#save-status').textContent = '코인명과 올바른 금액을 입력해 주세요.';
    return;
  }
  if (persist([...records(), trade])) {
    $('#trade-dialog').close();
    event.target.reset();
    $('#journal [name=date]').value = dateString(new Date());
    toast(demo ? '예시 모드에 기록을 추가했습니다. 실제 기록은 변경되지 않습니다.' : '새로운 거래를 기록했습니다. 오늘도 원칙을 지키는 투자!');
  }
};

$('#delete-trade').onclick = () => {
  if (confirm('이 거래 기록을 삭제할까요?') && persist(records().filter(trade => trade.id !== selectedId))) {
    $('#detail-dialog').close();
    toast('거래 기록을 삭제했습니다.');
  }
};
$('#search').oninput = render;
for (const button of document.querySelectorAll('[data-filter]')) {
  button.onclick = () => {
    filter = button.dataset.filter;
    for (const other of document.querySelectorAll('[data-filter]')) {
      other.classList.toggle('active', other === button);
      other.setAttribute('aria-pressed', String(other === button));
    }
    render();
  };
}
$('#demo-toggle').onclick = () => {
  demo = !demo;
  const url = new URL(location.href);
  if (demo) url.searchParams.set('demo', '1'); else url.searchParams.delete('demo');
  history.replaceState(null, '', url);
  okx.updateMode();
  $('#search').value = '';
  filter = 'all';
  for (const button of document.querySelectorAll('[data-filter]')) {
    button.classList.toggle('active', button.dataset.filter === 'all');
    button.setAttribute('aria-pressed', String(button.dataset.filter === 'all'));
  }
  render();
};
$('#export').onclick = () => {
  if (!demo && !storageReadable) { toast('기존 기록을 읽을 수 없어 내보내기를 중단했습니다. 저장 공간을 확인하세요.'); return; }
  const url = URL.createObjectURL(new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), currency: 'KRW', demo, trades: records() }, null, 2)], { type: 'application/json' }));
  const link = element('a');
  link.href = url;
  link.download = demo ? 'coin-journal-demo.json' : 'coin-journal.json';
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
};
for (const link of document.querySelectorAll('.nav-item')) {
  link.onclick = () => {
    for (const item of document.querySelectorAll('.nav-item')) item.classList.toggle('active', item === link);
    $('.breadcrumb strong').textContent = link.textContent.trim();
  };
}
render();
new ResizeObserver(() => renderChart(records().filter(trade => trade.exit !== null))).observe($('#chart'));

const okx = initOkx(() => demo);

let installPrompt = null;
const installButton = $('#install-app');
window.addEventListener('beforeinstallprompt', event => {
  event.preventDefault();
  installPrompt = event;
  installButton.hidden = false;
});
installButton.addEventListener('click', async () => {
  if (!installPrompt) return;
  await installPrompt.prompt();
  installPrompt = null;
  installButton.hidden = true;
});
window.addEventListener('appinstalled', () => {
  installPrompt = null;
  installButton.hidden = true;
  toast('Coin Journal을 홈 화면에 설치했습니다.');
});
if ('serviceWorker' in navigator && window.isSecureContext) {
  navigator.serviceWorker.register('/service-worker.js').catch(() => {
    // The application continues normally when offline support is unavailable.
  });
}
