const $ = selector => document.querySelector(selector);
const usd = value => value === null ? '—' : new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 2 }).format(Number(value));
const amount = value => value === null ? '—' : new Intl.NumberFormat('ko-KR', { maximumFractionDigits: 8 }).format(Number(value));

function cell(row, text, className) {
  const node = document.createElement('td');
  node.textContent = text;
  if (className) node.className = className;
  row.append(node);
  return node;
}

export function initOkx(isDemo) {
  let busy = false;
  let config = null;
  let snapshot = null;
  let error = '';

  async function api(path, method = 'GET') {
    const response = await fetch(path, { method, cache: 'no-store', headers: { 'X-Coin-Journal': '1' } });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message || '계정 정보를 조회하지 못했습니다.');
    return data;
  }

  function updateMode() {
    const demo = isDemo();
    const panel = $('#okx-panel');
    panel.classList.toggle('okx-error', Boolean(error));
    $('#okx-refresh').disabled = demo || busy;
    $('#okx-refresh').textContent = busy ? '조회 중…' : snapshot ? '새로 조회' : '연결 확인';
    $('#okx-connection').textContent = demo ? '예시 화면' : error ? '조회 실패' : snapshot ? '연결됨' : config?.configured ? '조회 준비됨' : '설정 필요';
    $('#okx-mode').textContent = config?.mode === 'demo' ? 'OKX 모의거래 계정' : 'OKX 실거래 계정';
    $('#okx-content').hidden = demo || !snapshot;
    $('#okx-setup').hidden = demo || Boolean(config?.configured);
    if (demo) {
      $('#okx-message').textContent = '예시 화면에서는 실제 계정을 조회하지 않습니다. 내 실제 기록으로 돌아가서 연결하세요.';
    } else if (error) {
      $('#okx-message').textContent = `${error}${snapshot ? ' 아래 값은 이전 조회 결과이며 최신 잔고가 아닙니다.' : ''}`;
    } else if (snapshot) {
      const time = new Intl.DateTimeFormat('ko-KR', { timeZone: 'Asia/Seoul', dateStyle: 'short', timeStyle: 'medium' }).format(new Date(snapshot.fetchedAt));
      $('#okx-message').textContent = `최근 조회 ${time} (한국 시간) · 거래 계정만 조회합니다. Funding 계정은 포함되지 않습니다.`;
    } else {
      $('#okx-message').textContent = config?.configured ? '키 설정을 확인했습니다. 연결 확인을 눌러 잔고와 보유 포지션을 조회하세요.' : 'Read 전용 API 키를 서버에 설정하면 내 잔고와 보유 포지션을 확인할 수 있습니다.';
    }
  }

  function renderSnapshot() {
    $('#okx-total').textContent = usd(snapshot.totalEquityUsd);
    $('#okx-balance-count').textContent = `${snapshot.balances.length}개`;
    $('#okx-position-count').textContent = `${snapshot.positions.length}건`;
    $('#okx-balances').replaceChildren();
    for (const balance of snapshot.balances) {
      const row = document.createElement('tr');
      cell(row, balance.currency);
      cell(row, amount(balance.equity));
      cell(row, amount(balance.available));
      cell(row, usd(balance.equityUsd));
      $('#okx-balances').append(row);
    }
    $('#okx-no-balances').hidden = snapshot.balances.length > 0;
    $('#okx-positions').replaceChildren();
    for (const position of snapshot.positions) {
      const row = document.createElement('tr');
      cell(row, position.instrument);
      const side = position.side === 'net' ? (Number(position.size) < 0 ? '숏 · 순포지션' : '롱 · 순포지션') : ({ long: '롱', short: '숏' })[position.side] || position.side;
      const margin = ({ cross: '교차', isolated: '격리' })[position.marginMode] || '';
      cell(row, `${side}${position.leverage ? ` · ${amount(position.leverage)}x` : ''}${margin ? ` · ${margin}` : ''}`);
      cell(row, `${amount(position.size)}${['SWAP', 'FUTURES', 'OPTION'].includes(position.type) ? ' 계약' : ''}`);
      cell(row, amount(position.averagePrice));
      cell(row, amount(position.markPrice));
      cell(row, amount(position.liquidationPrice));
      const pnl = cell(row, `${amount(position.unrealizedPnl)} ${position.settlementCurrency || '(OKX 결제 통화)'}`, Number(position.unrealizedPnl) < 0 ? 'negative' : 'positive');
      if (position.unrealizedPnlRatio !== null && position.unrealizedPnlRatio !== undefined) {
        const ratio = document.createElement('small');
        ratio.textContent = new Intl.NumberFormat('ko-KR', { style: 'percent', maximumFractionDigits: 2 }).format(Number(position.unrealizedPnlRatio));
        pnl.append(ratio);
      }
      $('#okx-positions').append(row);
    }
    $('#okx-no-positions').hidden = snapshot.positions.length > 0;
  }

  $('#okx-refresh').onclick = async () => {
    if (busy || isDemo()) return;
    busy = true;
    error = '';
    updateMode();
    try {
      config = await api('/api/okx/status');
      if (!config.configured) {
        $('#okx-setup').open = true;
        error = config.validMode ? 'API 키 설정이 필요합니다. 아래 연결 방법을 확인하세요.' : 'OKX_DEMO 설정에는 true 또는 false를 입력하세요.';
      } else {
        snapshot = await api('/api/okx/snapshot', 'POST');
        renderSnapshot();
      }
    } catch (failure) {
      error = failure.message === 'Failed to fetch' ? '앱 서버에 연결할 수 없습니다. 서버 실행 상태를 확인하세요.' : failure.message;
    } finally {
      busy = false;
      updateMode();
    }
  };

  api('/api/okx/status').then(value => { config = value; updateMode(); }).catch(() => {
    error = '연결 상태를 확인할 수 없습니다. 앱을 로컬 서버에서 실행했는지 확인하세요.';
    updateMode();
  });
  updateMode();
  return { updateMode };
}
