export function position({capital,risk,entry,stop,side}) {
  if (![capital,risk,entry,stop].every(n=>Number.isFinite(n)&&n>0) || risk>100) throw Error('모든 금액은 0보다 커야 하고 위험 비율은 100% 이하여야 합니다.');
  if(!['long','short'].includes(side)||(side==='long'?stop>=entry:stop<=entry)) throw Error('롱 손절가는 진입가보다 낮게, 숏 손절가는 높게 입력하세요.');
  const loss=capital*risk/100, quantity=loss/Math.abs(entry-stop);
  return {loss,quantity,notional:quantity*entry};
}
export function profit(t) {return t.exit===null?null:(t.exit-t.entry)*t.quantity*(t.side==='short'?-1:1)-t.fee;}
