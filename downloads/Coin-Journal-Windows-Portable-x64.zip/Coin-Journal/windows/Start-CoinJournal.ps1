$ErrorActionPreference = 'Stop'

$AppRoot = Split-Path -Parent $PSScriptRoot
$StateRoot = Join-Path $env:LOCALAPPDATA 'CoinJournal'
$CredentialFile = Join-Path $StateRoot 'credentials.json'
$ServerUrl = 'http://127.0.0.1:3000'
$StatusUrl = "$ServerUrl/api/okx/status"
$BundledNode = Join-Path $AppRoot 'runtime\node.exe'

function Show-Message([string]$Message, [string]$Title = 'Coin Journal') {
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show($Message, $Title) | Out-Null
}

function Convert-ToPlainText([Security.SecureString]$Value) {
    $Pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Value)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($Pointer)
    } finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($Pointer)
    }
}

function Save-Credentials {
    Write-Host ''
    Write-Host 'OKX Read 전용 API 정보를 입력하세요.' -ForegroundColor Green
    Write-Host '입력 내용은 화면에 표시되지 않으며 Windows 사용자 계정으로 암호화됩니다.'
    $ApiKey = Read-Host 'OKX API Key' -AsSecureString
    $ApiSecret = Read-Host 'OKX Secret Key' -AsSecureString
    $Passphrase = Read-Host 'OKX API Passphrase' -AsSecureString
    if ($ApiKey.Length -eq 0 -or $ApiSecret.Length -eq 0 -or $Passphrase.Length -eq 0) {
        throw '세 값을 모두 입력해야 합니다.'
    }
    New-Item -ItemType Directory -Force -Path $StateRoot | Out-Null
    @{
        apiKey = ConvertFrom-SecureString $ApiKey
        apiSecret = ConvertFrom-SecureString $ApiSecret
        passphrase = ConvertFrom-SecureString $Passphrase
    } | ConvertTo-Json | Set-Content -Encoding UTF8 -Path $CredentialFile
}

function Load-Credentials {
    if (-not (Test-Path $CredentialFile)) { Save-Credentials }
    try {
        $Stored = Get-Content -Raw -Path $CredentialFile | ConvertFrom-Json
        return @{
            apiKey = Convert-ToPlainText (ConvertTo-SecureString $Stored.apiKey)
            apiSecret = Convert-ToPlainText (ConvertTo-SecureString $Stored.apiSecret)
            passphrase = Convert-ToPlainText (ConvertTo-SecureString $Stored.passphrase)
        }
    } catch {
        throw "저장된 인증 정보를 읽을 수 없습니다. $CredentialFile 파일을 삭제한 뒤 다시 실행하세요."
    }
}

function Test-CoinJournalServer {
    try {
        $Response = Invoke-RestMethod -Uri $StatusUrl -Headers @{ 'X-Coin-Journal' = '1' } -TimeoutSec 2
        return $Response.configured -eq $true
    } catch {
        return $false
    }
}

try {
    Write-Host 'Coin Journal을 시작하는 중입니다...' -ForegroundColor Green
    if (Test-Path $BundledNode) {
        $NodePath = $BundledNode
    } else {
        $Node = Get-Command node.exe -ErrorAction SilentlyContinue
        $NodePath = if ($Node) { $Node.Source } else { $null }
    }
    if (-not $NodePath) {
        Show-Message "Coin Journal 실행에는 Node.js 24.5 이상이 필요합니다.`n`nNode.js를 설치한 뒤 다시 실행하세요:`nhttps://nodejs.org/" 'Node.js가 필요합니다'
        Start-Process 'https://nodejs.org/en/download'
        exit 1
    }
    $NodeVersion = (& $NodePath --version).TrimStart('v').Split('.')
    if ([int]$NodeVersion[0] -lt 24 -or ([int]$NodeVersion[0] -eq 24 -and [int]$NodeVersion[1] -lt 5)) {
        throw 'Node.js 24.5 이상이 필요합니다.'
    }

    if (-not (Test-CoinJournalServer)) {
        $Credentials = Load-Credentials
        $env:OKX_API_KEY = $Credentials.apiKey
        $env:OKX_API_SECRET = $Credentials.apiSecret
        $env:OKX_API_PASSPHRASE = $Credentials.passphrase
        $env:OKX_DEMO = 'false'
        $LogPath = Join-Path $StateRoot 'server.log'
        $ErrorLogPath = Join-Path $StateRoot 'server-error.log'
        Start-Process -FilePath $NodePath -ArgumentList @('--use-env-proxy', 'server.js') -WorkingDirectory $AppRoot -WindowStyle Hidden -RedirectStandardOutput $LogPath -RedirectStandardError $ErrorLogPath | Out-Null
        Remove-Item Env:OKX_API_KEY, Env:OKX_API_SECRET, Env:OKX_API_PASSPHRASE -ErrorAction SilentlyContinue
        $Credentials.Clear()

        $Ready = $false
        for ($Attempt = 0; $Attempt -lt 30; $Attempt++) {
            Start-Sleep -Milliseconds 200
            if (Test-CoinJournalServer) { $Ready = $true; break }
        }
        if (-not $Ready) {
            throw "서버를 시작하지 못했습니다. 로그를 확인하세요: $ErrorLogPath"
        }
    }

    Start-Process $ServerUrl
    Write-Host '브라우저에서 Coin Journal을 열었습니다.' -ForegroundColor Green
} catch {
    Show-Message $_.Exception.Message 'Coin Journal 실행 오류'
    exit 1
}

