$ErrorActionPreference = 'Stop'
$Launcher = Join-Path $PSScriptRoot 'Start-CoinJournal.ps1'
$Desktop = [Environment]::GetFolderPath('Desktop')
$ShortcutPath = Join-Path $Desktop 'Coin Journal.lnk'
$Shell = New-Object -ComObject WScript.Shell
$Shortcut = $Shell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = 'powershell.exe'
$Shortcut.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$Launcher`""
$Shortcut.WorkingDirectory = Split-Path -Parent $PSScriptRoot
$Shortcut.Description = 'Coin Journal · OKX 투자 기록'
$Shortcut.Save()
Add-Type -AssemblyName PresentationFramework
[System.Windows.MessageBox]::Show("바탕화면에 Coin Journal 바로가기를 만들었습니다.", 'Coin Journal') | Out-Null

