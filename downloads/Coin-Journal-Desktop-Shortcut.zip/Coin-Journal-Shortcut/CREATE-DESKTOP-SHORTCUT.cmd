@echo off
setlocal
chcp 65001 >nul
powershell.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0windows\Install-Desktop-Shortcut.ps1"
if errorlevel 1 pause
