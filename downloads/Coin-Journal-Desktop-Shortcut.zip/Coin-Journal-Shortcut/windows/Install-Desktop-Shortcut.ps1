﻿[CmdletBinding()]
param([string]$AppFolder)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

try {
    if (-not $AppFolder) { $AppFolder = Split-Path -Parent $PSScriptRoot }
    $Launcher = Join-Path $AppFolder 'START.cmd'
    if (-not (Test-Path -LiteralPath $Launcher -PathType Leaf)) {
        $Picker = New-Object System.Windows.Forms.OpenFileDialog
        $Picker.Title = '현재 사용하는 Coin-Journal 폴더의 START.cmd를 선택하세요'
        $Picker.Filter = 'Coin Journal 실행 파일 (START.cmd)|START.cmd'
        $Picker.FileName = 'START.cmd'
        $Picker.CheckFileExists = $true
        try {
            if ($Picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 0 }
            $Launcher = $Picker.FileName
            $AppFolder = Split-Path -Parent $Launcher
        } finally { $Picker.Dispose() }
    }
    if (-not (Test-Path -LiteralPath (Join-Path $AppFolder 'windows/Start-CoinJournal.ps1') -PathType Leaf)) {
        throw 'Coin Journal 실행기 파일이 없습니다. 정상 실행되는 Coin-Journal 폴더의 START.cmd를 선택하세요.'
    }
    $AppFolder = (Resolve-Path -LiteralPath $AppFolder).Path
    $Launcher = Join-Path $AppFolder 'START.cmd'

    # Persist the icon outside the installer so removing its download does not break the shortcut.
    $IconSource = Join-Path $PSScriptRoot 'coin-journal.ico'
    if (-not (Test-Path -LiteralPath $IconSource -PathType Leaf)) {
        throw '아이콘 파일을 찾지 못했습니다. 바로가기 설치 ZIP 전체를 압축 해제하세요.'
    }
    $IconFolder = Join-Path $env:LOCALAPPDATA 'CoinJournal'
    New-Item -ItemType Directory -Force -Path $IconFolder | Out-Null
    $IconPath = Join-Path $IconFolder 'desktop-icon.ico'
    Copy-Item -LiteralPath $IconSource -Destination $IconPath -Force

    $Desktop = [Environment]::GetFolderPath('Desktop')
    if (-not $Desktop) { throw '현재 Windows 사용자의 바탕화면 폴더를 찾을 수 없습니다.' }
    New-Item -ItemType Directory -Force -Path $Desktop | Out-Null
    $ShortcutPath = Join-Path $Desktop 'Coin Journal.lnk'
    $Shell = New-Object -ComObject WScript.Shell
    $Shortcut = $Shell.CreateShortcut($ShortcutPath)
    $Shortcut.TargetPath = Join-Path $env:SystemRoot 'System32/cmd.exe'
    $Shortcut.Arguments = '/c ""' + $Launcher + '""'
    $Shortcut.WorkingDirectory = $AppFolder
    $Shortcut.IconLocation = $IconPath + ',0'
    $Shortcut.Description = 'Coin Journal - OKX 투자 기록'
    $Shortcut.WindowStyle = 1
    $Shortcut.Save()
    if (-not (Test-Path -LiteralPath $ShortcutPath)) { throw '바로가기 파일이 저장되지 않았습니다.' }
    [System.Windows.Forms.MessageBox]::Show("바탕화면에 Coin Journal 아이콘을 만들었습니다.`n`n이제 아이콘을 더블클릭해 실행하세요.", 'Coin Journal') | Out-Null
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, '바로가기 생성 오류') | Out-Null
    exit 1
}
