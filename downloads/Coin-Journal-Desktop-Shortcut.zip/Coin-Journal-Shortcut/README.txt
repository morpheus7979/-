﻿Coin Journal 바탕화면 아이콘 만들기

1. 이 ZIP 파일 전체를 압축 해제합니다.
2. CREATE-DESKTOP-SHORTCUT.cmd를 더블클릭합니다.
3. 파일 선택창에서 현재 사용 중인 Coin-Journal 폴더의 START.cmd를 선택합니다.
4. 바탕화면에 생성된 Coin Journal 아이콘을 더블클릭합니다.

실행 폴더를 이동하면 이 설치기를 다시 실행해 새 위치를 선택하세요.
이 설치기는 바탕화면 바로가기와 아이콘 파일만 만듭니다.